const sql = require("mssql");
require("dotenv").config();

const config = {
  server: process.env.DB_SERVER,
  database: process.env.DB_DATABASE,
  options: {
    encrypt: process.env.DB_ENCRYPT === "true",
    trustServerCertificate: process.env.DB_TRUST_SERVER_CERTIFICATE === "true",
  },
};
// declared at module level so all files share the same instance

const connectDB = async () => {
  try {
   const pool = await sql.connect(config); // assigns to the module-level variable
    console.log("Connected to SQL Server");
    return pool;
  } catch (error) {
    console.error("Database connection failed:", error.message);
    throw error;
  }
};


module.exports = {
  sql,
  connectDB,
};