const express = require("express");
const { connectDB } = require("./config/database");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());

app.get("", (req, res) => {
  res.json({
    message: "CareerBridge API is running",
  });
});


app.get("/api/health", (req, res) => {
  res.json({
    success: true,
    message: "CareerBridge API is healthy",
  });
});

app.get("/api/jobs", async (req, res) => {
    const pool = await connectDB();

    const result = await pool
    .request()
    .query("SELECT * FROM Job");
    res.json(result.recordset);
});

    app.listen(PORT, () => {
      console.log(`CareerBridge API running on port ${PORT}`);
    });

